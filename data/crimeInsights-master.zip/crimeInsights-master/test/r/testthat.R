library(testthat)
test_dir(here::here("test/r/testthat/"), stop_on_failure = TRUE)
